UTBK PROGRESS TRACKER 2027

Isi folder:
- index.html: aplikasi
- manifest.webmanifest: konfigurasi installable web app
- sw.js: cache offline sederhana

CARA PAKAI:
1. Ekstrak ZIP ini.
2. Untuk mencoba cepat, buka index.html di browser.
3. Agar bisa dipasang seperti aplikasi (Add to Home Screen) dan service worker aktif, unggah folder ini ke hosting HTTPS statis seperti GitHub Pages.
4. Buka alamat hosting di Chrome Android > menu titik tiga > Install app / Tambahkan ke layar utama.

CATATAN:
- Data tersimpan di localStorage browser/perangkat ini. Jangan hapus data situs jika ingin mempertahankan catatan.
- Belum ada sinkronisasi cloud atau login.
- Tanggal 21 April 2027 hanya patokan hitung mundur, bukan tanggal UTBK resmi.
